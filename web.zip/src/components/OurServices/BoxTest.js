function BoxTest() {
  return (
    <div>
      <h1>Test</h1>
      <div></div>
    </div>
  );
}

export default BoxTest;
